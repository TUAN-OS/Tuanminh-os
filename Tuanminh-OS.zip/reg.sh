read -p "enter register key: " ar
if [[ $ar = "NT212-938JD-TN82I-9KSOE" ]]
then
	echo $ar > rgkey.ini
	clear
	bash main.sh
	
elif [[ $ar = "KRUNS-9NTFD-9NDSE-IDOS3" ]]
then
	echo $ar > rgkey.ini
	clear
	bash main.sh

elif [[ $ar = "KUDO3-9JD990-FJ8S4-9493J" ]]
then
	echo $ar > rgkey.ini
	clear
	bash main.sh
else
	echo PLEASE RE-ENTER THIS KEY
	echo $els
	clear
	bash reg.sh
fi