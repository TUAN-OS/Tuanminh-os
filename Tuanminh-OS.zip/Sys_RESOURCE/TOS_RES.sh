#!/bin/bash
echo Welcome to Tuanminh-OS v1.00, it in the beta and if you can,  help me
echo My frist os, i hope you can help me.
echo typiyng cd funcs
echo then type source /funcs/[nameofscript.sh]
echo $els
echo NOTIFICATION: You need to type ~/Tuanminh-OS/Sys_RESOURCE/lib/cmdlib.sh
echo 81 MB/S processor, 194 MB left.
echo $els