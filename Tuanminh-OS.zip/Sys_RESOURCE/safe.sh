#!/bin/bash
echo Welcome to Tuanminh-OS v1.00, it in the beta and if you can,  help me
echo My frist os, i hope you can help me.
echo SAFE MODE
echo you cannot execute or using a applcation in this os
RGKEY=~/Tuanminh-OS/rgkey.ini
if [ -f "$RGKEY" ]; then
    echo $els
    echo This OS registed! You can use this OS now!
    echo $els
else 
    echo $els
    echo You need to register to this OS for use this OS
    bash reg.sh
fi
echo typiyng cd funcs
echo then type source /funcs/[nameofscript.sh]
echo $els
echo NOTIFICATION: You need to type source ~/Tuanminh-OS/Sys_RESOURCE/lib/cmdsafe.sh
echo 81 MB/S processor, 194 MB left.
echo $els