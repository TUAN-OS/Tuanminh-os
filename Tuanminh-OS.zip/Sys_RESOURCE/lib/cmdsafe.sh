alias chg-directory="cd"
alias chg-drc-uponelvl="cd .."
alias cmdlist="cat clist"
alias print-oput="echo"