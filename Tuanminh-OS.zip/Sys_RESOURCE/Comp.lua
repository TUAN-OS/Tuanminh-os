print("Tuanminh-OS lua script.")
if TOS_RES==nul or main.sh==null then
  print("ERROR: Missing files")
end