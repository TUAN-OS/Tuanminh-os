#Copyright 2021 (c) Tuanminh-OS by CEAA.TuanminhLittleProject(r)
#All rights reserved.
#
#TODO:
#-Help you to use bash is easy
#-New function: calculator (current version)
#Version:
#v1.00.00
#v1.00.02
#v1.00.03 (current version)

echo Copyright 2021 (c) Tuanminh-OS by CEAA.TuanminhLittleProject(r)
echo All rights reserved.
echo $null
echo TODO:
echo -Help you to use bash is easy
echo -New function: calculator (current version)
echo Version:
echo v1.00.00