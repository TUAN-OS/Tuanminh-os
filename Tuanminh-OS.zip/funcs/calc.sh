#!/bin/bash
#!/1sys
echo Calculator v1.00
echo used by Tuanminh-OS
echo If you want back to tuanminh-OS, you can typying cd .., then cd 1sys, then bash main.sh
echo $elf
read -p 'num1 is:' num1
read -p 'num2 is:' num2
echo num1 is $num1
echo num2 is $num2
echo then
echo add=`expr $num1 + $num2`
echo sub=`expr $num1 - $num2`
echo mul=`expr $num1 \* $num2`
echo div=`expr $num1 + $num2`